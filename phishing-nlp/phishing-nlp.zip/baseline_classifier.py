# baseline_classifier.py
# Simple AI/NLP baseline: TF-IDF + Logistic Regression / Linear SVM

import re
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# ====== 1) CONFIG ======
DATA_PATH = Path("data/sample.csv")   # starter dataset
TEXT_COL  = "text"
LABEL_COL = "label"

# ====== 2) LOAD DATA ======
df = pd.read_csv(DATA_PATH)
print("Columns found:", df.columns.tolist())
df = df[[TEXT_COL, LABEL_COL]].dropna().copy()

# Map labels to numbers
unique_labels = sorted(df[LABEL_COL].unique())
label_map = {lbl: i for i, lbl in enumerate(unique_labels)}
inv_label_map = {v: k for k, v in label_map.items()}
df["y"] = df[LABEL_COL].map(label_map)

# ====== 3) CLEAN TEXT ======
def clean_text(s: str) -> str:
    s = str(s).lower()
    s = re.sub(r"\s+", " ", s)
    return s.strip()

df["x"] = df[TEXT_COL].apply(clean_text)

# ====== 4) SPLIT ======
X_train, X_test, y_train, y_test = train_test_split(
    df["x"], df["y"], test_size=0.5, stratify=df["y"], random_state=42
)

# ====== 5) MODELS ======
def make_pipeline(clf):
    return Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1,2), min_df=1, max_df=0.95, stop_words="english")),
        ("clf", clf),
    ])

models = {
    "LogisticRegression": LogisticRegression(max_iter=2000),
    "LinearSVM": LinearSVC()
}

# ====== 6) TRAIN + EVAL ======
for name, clf in models.items():
    pipe = make_pipeline(clf)
    pipe.fit(X_train, y_train)
    preds = pipe.predict(X_test)

    acc = accuracy_score(y_test, preds)
    report = classification_report(y_test, preds, target_names=[inv_label_map[i] for i in range(len(unique_labels))])
    cm = confusion_matrix(y_test, preds)

    print(f"\n=== {name} ===")
    print(f"Accuracy: {acc:.3f}")
    print(report)
    print("Confusion matrix:\n", cm)
